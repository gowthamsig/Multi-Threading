/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csye_assignment1;

/**
 *
 * @author Gowtham
 */
import static org.junit.Assert.*;
import java.util.*;

import org.junit.Test;

import csye_assignment1.ParallelMaximizer;

public class PublicTest {

    private static int numThreads = 4; // number of threads for the maximizer
    private static int numElements = 10000;

    public static void main(String[] args) {
        // number of integers in the list
        Random rand = new Random();
        ParallelMaximizer maximizer = new ParallelMaximizer(numThreads);
        LinkedList<Integer> list = new LinkedList<Integer>();
        int serialMax = Integer.MIN_VALUE;

        // populate the list
        // TODO: change this implementation to test accordingly
        for (int i = 0; i < numElements; i++) {
            int next = rand.nextInt();
            list.add(next);
            serialMax = Math.max(serialMax, next);
        }

        // run the maximizer
        try {
            System.out.println("Serial Maximum value is " + serialMax);
            System.out.println("Parallel Maximum value is " + maximizer.max(list));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
