package multi_assignment3;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Semaphore;

/**
 * Customers are simulation actors that have two fields: a name, and a list of
 * Food items that constitute the Customer's order. When running, an customer
 * attempts to enter the coffee shop (only successful if the coffee shop has a
 * free table), place its order, and then leave the coffee shop when the order
 * is complete.
 */
public class Customer implements Runnable {

    //JUST ONE SET OF IDEAS ON HOW TO SET THINGS UP...
    private final String custName;
    private final LinkedList<Food> order;
    private final int orderNum;
    private final int priority;
    private static int runningCounter = 0;
    private static int tables;

    private static Semaphore tablelist = null;
    LinkedList<Orders> orders = null;

    /**
     * You can feel free modify this constructor. It must take at least the name
     * and order but may take other parameters if you would find adding them
     * useful.
     *
     * @param name
     * @param order
     * @param numTables
     * @param orders
     * @param priority
     */
    public Customer(String name, LinkedList<Food> order, int numTables, LinkedList<Orders> ordersList,
            int priority) {
        this.custName = name;
        this.order = order;
        this.orderNum = ++runningCounter;
        this.priority = priority;
        if (tablelist == null) {
            tables = numTables;
            tablelist = new Semaphore(tables);
        }
        Simulation.custOrder.put(this, false);
        orders = ordersList;
    }

    public String toString() {
        return custName;
    }

    public int getPriority() {
        return priority;
    }

    /**
     * This method defines what an Customer does: The customer attempts to enter
     * the coffee shop (only successful when the coffee shop has a free table),
     * place its order, and then leave the coffee shop when the order is
     * complete.
     */
    public void run() {
		//YOUR CODE GOES HERE...

        Simulation.logEvent(SimulationEvent.customerStarting(this));
        try {

            tablelist.acquire();

            Simulation.logEvent(SimulationEvent.customerEnteredCoffeeShop(this));

            synchronized (orders) {
                orders.add(new Orders(this.orderNum, this.order, this));
                Simulation.logEvent(SimulationEvent.customerPlacedOrder(this, this.order, this.orderNum));
                orders.notifyAll();
            }

            while (Simulation.custOrder.get(this) == false) {
                Thread.sleep(15);
            }

            Simulation.logEvent(SimulationEvent.customerReceivedOrder(this, this.order, this.orderNum));
            Simulation.logEvent(SimulationEvent.customerLeavingCoffeeShop(this));
            tablelist.release();

        } catch (InterruptedException e) {

        }

    }

}
