package multi_assignment3;

import java.util.LinkedList;

public class Orders {

	private final int orderNum;
	private final LinkedList<Food> order;
	private boolean isFinished;
	private final Customer customer;

	public Orders(int orderNum, LinkedList<Food> order, Customer customerIn) {
		this.order = order;
		this.orderNum = orderNum;
		this.customer = customerIn;
	}

	public LinkedList<Food> getListOfFood() {
		return this.order;
	}

	public int getOrderNum() {
		return this.orderNum;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public boolean isDone() {
		return this.isFinished;
	}
	
	public String toString() {
		return "Order Number " + this.orderNum + "\n" + this.customer.toString()
				+ "\n" + this.isFinished;
	}
}
